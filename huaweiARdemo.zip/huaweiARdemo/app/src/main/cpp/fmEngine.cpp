//
// Created by 梦海 on 2017/4/1.
//

#include "fmEngine.h"
//#include "opencv2/opencv.hpp"
//#include "FaceTracker.h"
#include "pch.h"
#include "time.h"
extern int clock_gettime(int, struct timespec *);
struct timespec now;
char *data = new char[720*1280*3/2];
static unsigned int showTex = 0;
static unsigned int yTex = 0;
static unsigned int uvTex = 0;
unsigned int yuvWidth = 800;
unsigned int yuvHeight = 1280;
//static unsigned int grayTex = 0;
//static unsigned char *grayData = new unsigned char[720*1280];
//static unsigned char *rgbaData = new unsigned char[720*1280*4];
//FaceTracker* fm = nullptr;
void fmEngine::create() {
    __android_log_print(ANDROID_LOG_ERROR, "ar", "shiyang ar mEngine::create()");
    draw = new fmDrawer();
    draw->loaderShader();

    drawYUV = new fmDrawerYUV();
    drawYUV->loaderShader();
    
//    drawGray = new fmDrawerGray();
//    drawGray->loaderShader();
//
//    drawPoints = new fmDrawerPoints();
//    drawPoints->loaderShader();
    
    glGenTextures(1,&showTex);
    glBindTexture(GL_TEXTURE_2D,showTex);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,yuvWidth,yuvHeight,0,GL_RGBA,GL_UNSIGNED_BYTE, nullptr);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
    glBindTexture(GL_TEXTURE_2D, 0);
    
    glGenTextures(1,&yTex);
    glBindTexture(GL_TEXTURE_2D,yTex);
    glTexImage2D(GL_TEXTURE_2D,0,GL_LUMINANCE,yuvWidth,yuvHeight,0,GL_LUMINANCE,GL_UNSIGNED_BYTE, nullptr);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
    glBindTexture(GL_TEXTURE_2D, 0);
    
    glGenTextures(1,&uvTex);
    glBindTexture(GL_TEXTURE_2D,uvTex);
    glTexImage2D(GL_TEXTURE_2D,0,GL_LUMINANCE_ALPHA,yuvWidth/2,yuvHeight/2,0,GL_LUMINANCE_ALPHA,GL_UNSIGNED_BYTE, nullptr);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
    glBindTexture(GL_TEXTURE_2D, 0);

//    glGenTextures(1,&grayTex);
//    glBindTexture(GL_TEXTURE_2D,grayTex);
//    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,720,1280,0,GL_RGBA,GL_UNSIGNED_BYTE, nullptr);
//    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
//    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
//    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
//    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
//
//    grayData = new unsigned char[720*1280];
//    rgbaData = new unsigned char[720*1280*4];
//    memset(rgbaData, 255, 720*1280*4);
}


bool useSDYUV = false;


void fmEngine::testYUV() {
    FILE* pYUV = fopen("/storage/emulated/0/ws23.yuv", "r");
    int lenPerFrame = 1280*720*3/2;
    int Frame = 50;
    int len = lenPerFrame*Frame;
    unsigned char *buf = new unsigned char[len];
    if (pYUV) {
        NSLog("shiyang open yuv success\n");
        fread(buf, 1, len, pYUV);
        fclose(pYUV);
    } else {
        NSLog("shiyang open yuv failed\n");
    }

    int colorType = 1;
    int face_rotate = 3;
//    if (fm != nullptr) {
//        NSLog("shiyang fm != nullptr");
//    } else {
//        NSLog("shiyang fm == nullptr");
//    }


//    for (int i=0; i<10; i++) {
//        std::vector<FacialInfo> result_list =
//                fm->FacialLandmarkDetectInVideo((char *)(buf+i*lenPerFrame), 720, 1280,
//                                                colorType * 720 * sizeof(char),
//                                                colorType, faceOritation(face_rotate));
//        int m_face_count = result_list.size();
//        NSLog("shiyang detectSELF face count = %d", m_face_count);
//    }


    float time_cost[Frame];
    float sum = 0.0;
//    int num_ignore = 0;
//    bool needIgnore = false;
//    for (int i=0; i<Frame; i++) {
//
//        // begin
//        clock_gettime(CLOCK_MONOTONIC, &now);
//        long long int time_begin = now.tv_sec * 1000000000LL + now.tv_nsec;
//        std::vector<FacialInfo> result_list =
//                fm->FacialLandmarkDetectInVideo((char *)(buf+i*lenPerFrame), 720, 1280,
//                                                           colorType * 720 * sizeof(char), colorType,
//                                                faceOritation(face_rotate));
//        clock_gettime(CLOCK_MONOTONIC, &now);
//        long long int time_end = now.tv_sec * 1000000000LL + now.tv_nsec;
//        time_cost[i] = (time_end - time_begin)/1000000.0f;
////        if (i%10 == 9) {
////            time_cost[i] = 0.0f;
////        }
//        sum += time_cost[i];
//
//        int m_face_count = result_list.size();
//        NSLog("shiyang detectSELF face count = %d", m_face_count);
//    }

    NSLog("shiyang self time_cost_sum=%f avg=%f", sum, sum/Frame);

    for (int i=0; i<Frame; i++) {
        NSLog("shiyang self time_cost[%d]=%f", i, time_cost[i]);
    }

}

void fmEngine::sendData(unsigned char *_data) {
    __android_log_print(ANDROID_LOG_ERROR, "ar", "shiyang ar mEngine::sendData()");
    if (nullptr == _data) {
        NSLog("shiyang _data is nullptr");
        return;
    }
    
//    memset(_data, 0, yuvWidth*yuvHeight*3/2);
//    unsigned char *fakeData = new unsigned char[yuvWidth*yuvHeight*3/2];

    

    unsigned char *yData = new unsigned char[yuvWidth*yuvHeight];
    unsigned char *uvData = new unsigned char[yuvWidth*yuvHeight/2];
    
    memcpy(yData, _data, yuvWidth*yuvHeight);
    memcpy(uvData, _data+yuvWidth*yuvHeight, yuvWidth*yuvHeight/2);
    
    __android_log_print(ANDROID_LOG_ERROR, "ar", "shiyang ar mEngine::y0=%u<-%u", yData[0], _data[0]);
    __android_log_print(ANDROID_LOG_ERROR, "ar", "shiyang ar mEngine::y100=%u<-%u", yData[100], _data[0]);
    __android_log_print(ANDROID_LOG_ERROR, "ar", "shiyang ar mEngine::y1000=%u<-%u", yData[1000], _data[0]);
    
    glBindTexture(GL_TEXTURE_2D, yTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, yuvWidth, yuvHeight, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, yData);
    glBindTexture(GL_TEXTURE_2D, 0);
    
    glBindTexture(GL_TEXTURE_2D,uvTex);
    glTexImage2D(GL_TEXTURE_2D,0,GL_LUMINANCE_ALPHA,yuvWidth/2,yuvHeight/2,0,GL_LUMINANCE_ALPHA,GL_UNSIGNED_BYTE, uvData);
    glBindTexture(GL_TEXTURE_2D, 0);
    
//    delete[] fakeData;
    delete[] yData;
    delete[] uvData;
    
//    memcpy(grayData, _data, 720*1280);
//    drawGray->sendGrayData(grayData);

//    memcpy(grayData, _data, 1280*720);
//    memcpy(rgbaData, grayData, 1280*720);
//    memcpy(grayData+1280*720, grayData, 1280*720);
//    memcpy(grayData+1280*720*2, grayData, 1280*720);

//    int len = 1280*720*3/2;

//    memcpy(data, _data, len);

//    clock_gettime(CLOCK_MONOTONIC, &now);
//    long long int time_begin = now.tv_sec * 1000000000LL + now.tv_nsec;

//    std::vector<FacialInfo> result = fm->FacialLandmarkDetectInVideo((char *)_data, 1280, 720, 1280*sizeof(char), 1, faceOritation(3));
//    std::vector<FacialInfo> result = fm->FacialLandmarkDetectInVideo(data, 720, 1280, 720*sizeof(char), 1, faceOritation(0));

//    clock_gettime(CLOCK_MONOTONIC, &now);//yang
//    long long int time_end = now.tv_sec * 1000000000LL + now.tv_nsec;//yang
//    float time_delta = (time_end - time_begin)/1000000.0f;
//    int m_face_count = result.size();
//    if (m_face_count) {
//        NSLog("time_delta %f", time_delta);
//    } else {
//        NSLog("time_delta -1");
//    }


//    float facePoints[68*2];
//    if (m_face_count) {
//        for (int j = 0; j < result.at(0).facialLandMarklist.size(); ++j) {
//            PtInfo ptInfo = result.at(0).facialLandMarklist.at(j);
//
//            facePoints[j*2+0] = -(ptInfo.y/720.0f-0.5f)*2.0f;
//            facePoints[j*2+1] = (ptInfo.x/1280.0f-0.5f)*2.0f;
//        }
//        drawPoints->sendFacePoints(facePoints);
//    } else {
//        drawPoints->sendFacePoints(nullptr);
//    }

}

void fmEngine::drawTex(int id) {
//    if (useSDYUV) {
//        testYUV();
//        useSDYUV = false;
//        return;
//    }

    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, 720, 1280);
    glClearColor(1, 0, 1, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    
//    drawYUV->setRotation(90);
    drawYUV->drawTextureYUV(showTex, yTex, uvTex);
    
//    draw->setRotation(90);
//    draw->drawTextrue(id);
//
////    glBindTexture(GL_TEXTURE_2D,grayTex);
////    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 720,1280,GL_RGBA,GL_UNSIGNED_BYTE,rgbaData);
//
//    drawGray->setRotation(90);
//    drawGray->drawTextrue(id);
//
//    drawPoints->setRotation(90);
//    drawPoints->drawPoints(id);
}


