package appmagics.avatardemo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import com.unity3d.player.UnityPlayer;

import org.json.JSONObject;

import java.nio.ByteBuffer;

public class MainActivity extends /*AppCompat*/Activity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    private CameraSurfaceView mCameraSurfaceView;
    private Tracker mTracker;
    private TrackerData mTrackerData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mCameraSurfaceView = (CameraSurfaceView) findViewById(R.id.camera_surface);

        mCameraSurfaceView.setCameraPreviewListener(cameraPreviewListener);

        // Example of a call to a native method
//        TextView tv = (TextView) findViewById(R.id.sample_text);
//        tv.setText(stringFromJNI());
//        stringFromJNI();
//        initJNI();
//        mTracker = new Tracker();
//        mTracker.initialise(getApplicationContext(), 0, 1280, 720, 5, null, 270);
        mTrackerData = new TrackerData();
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
//    public native String stringFromJNI();
//    public native void initJNI();

    private ByteBuffer mCameraDataBuffer;
    private float[] mTrackerDataOutBuffer;
    int mTrackerDataOutLen = 101*2+3+1;
    CameraSurfaceView.OnCameraPreviewListener cameraPreviewListener =
            new CameraSurfaceView.OnCameraPreviewListener() {

        @Override
        public void callback(byte[] data, int width, int height) {
//            if(lastTime != 0) {
////                LogUtil.debug(getClass(), "Preview Time = " + (System.currentTimeMillis() - lastTime));
//            }
//
////            LogUtil.debug(getClass(), "width * width = " + width + "," + height);
//
//            lastTime = System.currentTimeMillis();
            try {
                if(mTracker == null) {
                    mTracker = new Tracker();
                } else {
                    try {
                        int size = width * height * 3 / 2;

                        if (mCameraDataBuffer == null) {
                            mCameraDataBuffer = ByteBuffer.allocateDirect(size);//分配空间
                        }
                        mCameraDataBuffer.rewind();
                        mCameraDataBuffer.put(data);
    
                        if (mTrackerDataOutBuffer == null) {
                            mTrackerDataOutBuffer = new float[mTrackerDataOutLen];
                        }
                        
                        mTracker.detect(getApplicationContext(), 0, width, height, 5, null, 270,
                                mCameraDataBuffer, mTrackerDataOutBuffer);
                        if (mTrackerDataOutBuffer[mTrackerDataOutLen-1] > 0.5) {
                            // has face
                            Log.e("shiyang", "shiyang dataout has face ");

                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("points", Utils.arrayToString(mTrackerDataOutBuffer));

                            jsonObject.put("roll", mTrackerDataOutBuffer[2*101+0]);
                            jsonObject.put("pitch", mTrackerDataOutBuffer[2*101+1]);
                            jsonObject.put("yaw", mTrackerDataOutBuffer[2*101+2]);
                            UnityPlayer.UnitySendMessage("HONGRUAN_RECEIVER", "ReceiveFaceData", jsonObject.toString());
                            
                            
                        } else {
                            Log.e("shiyang", "shiyang dataout has no face");
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("points", "");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                   
//                    mFaceTracker.init(width, height, FaceTracker.mImgFormat.IMG_NV21, MainActivity.this);
//                    mFaceTracker.setGetLandMarkCallback(new LandMarkValCallback() {
//                        @Override
//                        public void getLandMark(LandMarkVal landmark) {
//                            try {
//                                isCallback = true;
//                                JSONObject jsonObject = new JSONObject();
//                                jsonObject.put("points", landmark.landmark == null ? "" : Utils.arrayToString(landmark.landmark));
//
//                                jsonObject.put("mouthSize", landmark.mouthNormalSize);
//                                jsonObject.put("EyeState", landmark.lefteye_state);
//                                jsonObject.put("EyeXDis", landmark.eyeXDis);
//                                jsonObject.put("GetHaveFace", landmark.haveface);
//                                jsonObject.put("roll", -landmark.roll);
//                                jsonObject.put("pitch", landmark.pitch);
//                                jsonObject.put("yaw", -landmark.yaw);
//                                jsonObject.put("rightEyeDistance", landmark.rightEyeliddistan);
//                                jsonObject.put("leftEyeDistance", landmark.leftEyeliddistan);
//                                jsonObject.put("RightMouthC", landmark.rightMouthC);
//                                jsonObject.put("LeftMouthC", landmark.leftMouthC);
//                                jsonObject.put("rightEyeBrow", landmark.rightEyeBrow);
//                                jsonObject.put("leftEyeBrow", landmark.leftEyeBrow);
//                                UnityPlayer.UnitySendMessage("HONGRUAN_RECEIVER", "ReceiveFaceData", jsonObject.toString());
//
////                                LogUtil.debug(getClass(), "mFaceTime = " + (System.currentTimeMillis() - mFaceTime));
//                                mFaceTime = System.currentTimeMillis();
//                            } catch (JSONException e) {
//                                e.printStackTrace();
//                            }
//
//                        }
//                    });
                }
//                if(mFaceTracker.mLandMarkVal != null){
//                    mFaceTracker.mLandMarkVal.clearLandMarkVal();
//                }
//
//                mFaceTracker.notifyProcess(data);
//                if(isCallback) {
//                    isCallback = false;
//
//                }
//
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
}
