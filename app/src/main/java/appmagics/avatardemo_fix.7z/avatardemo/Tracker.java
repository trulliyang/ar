package appmagics.avatardemo;

import android.content.Context;

import java.nio.ByteBuffer;

/**
 * Created by admin on 2017/10/20.
 */

public class Tracker {
    static {
        System.loadLibrary("native-lib");
    }

    public void initialise(Context context, int type, int width, int height, int format, String path, int angle) {
//        testJNI(context,type, width,  height, format, path, angle);
//        detectJNI(context,type, width,  height, format, path, angle);
    }

    public void detect(Context context, int type, int width, int height, int format, String path,
                       int angle, ByteBuffer data, float[] dataout) {
        detectJNI(context,type, width,  height, format, path, angle, data, dataout);
    }

    public float[] getTrackerData() {
        float[] data = getDataJNI();
        return data;
    }

    public native void testJNI(Context context, int type, int width, int height, int format, String path, int angle);
    public native void detectJNI(Context context, int type, int width, int height, int format,
                                 String path, int angle, ByteBuffer data, float[] dataout);
    public native float[] getDataJNI();
}
