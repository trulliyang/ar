package appmagics.avatardemo;

import android.graphics.Bitmap;

/**
 * Created by admin on 2017/10/20.
 */

public interface TakePictureInterface {
    void onTakePicture(Bitmap bitmap);
}
