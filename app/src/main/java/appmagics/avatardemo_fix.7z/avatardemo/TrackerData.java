package appmagics.avatardemo;

/**
 * Created by admin on 2017/10/21.
 */

public class TrackerData {
    float[] mPoints;
    float[] mRollYawPitch;
}
